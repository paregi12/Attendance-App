const QRCode = require("qrcode");

// ✅ Generate 6-digit OTP
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// ✅ Generate QR code string (base64 image)
async function generateQRCode(text) {
  try {
    return await QRCode.toDataURL(text);
  } catch (err) {
    console.error(err);
    return null;
  }
}

module.exports = { generateOTP, generateQRCode };