const functions = require("firebase-functions");
const admin = require("firebase-admin");
const { generateOTP, generateQRCode } = require("./api");

admin.initializeApp();
const db = admin.firestore();

// ✅ 1. Register user (teacher/student)
exports.registerUser = functions.https.onCall(async (data, context) => {
  const { name, email, role, rollNumber, deviceId } = data;

  if (!name || !email || !role) {
    throw new functions.https.HttpsError("invalid-argument", "Missing fields");
  }

  const userRef = db.collection("users").doc(email);
  const userDoc = await userRef.get();

  if (userDoc.exists) {
    throw new functions.https.HttpsError("already-exists", "User already registered");
  }

  await userRef.set({
    name,
    email,
    role,
    rollNumber: rollNumber || null,
    deviceId: deviceId || null,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return { success: true };
});

// ✅ 2. Teacher creates a lecture
exports.createLecture = functions.https.onCall(async (data, context) => {
  const { teacherEmail, course, semester, division, subDivision, startTime, endTime } = data;

  const lectureRef = db.collection("lectures").doc();
  await lectureRef.set({
    teacherEmail,
    course,
    semester,
    division,
    subDivision,
    startTime,
    endTime,
    otp: generateOTP(),
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  return { lectureId: lectureRef.id };
});

// ✅ 3. Generate OTP + QR for lecture
exports.getLectureCredentials