package com.collegeattendance;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class TeacherDashboardActivity extends AppCompatActivity {

    Button createLectureBtn, generateOtpBtn, generateQrBtn, gpsAlertBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_dashboard);

        createLectureBtn = findViewById(R.id.createLectureBtn);
        generateOtpBtn = findViewById(R.id.generateOtpBtn);
        generateQrBtn = findViewById(R.id.generateQrBtn);
        gpsAlertBtn = findViewById(R.id.gpsAlertBtn);

        // TODO: connect to Firebase
    }
}