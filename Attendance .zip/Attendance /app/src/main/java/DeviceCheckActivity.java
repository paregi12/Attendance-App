package com.collegeattendance;

import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DeviceCheckActivity extends AppCompatActivity {

    TextView deviceIdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_check);

        String deviceID = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        deviceIdView = findViewById(R.id.deviceIdView);
        deviceIdView.setText("Device ID: " + deviceID);

        // TODO: send this ID to Firebase for validation
    }
}