package com.collegeattendance;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class QRActivity extends AppCompatActivity {

    TextView qrCodeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);

        qrCodeView = findViewById(R.id.qrCodeView);

        // TODO: generate unique QR per student
    }
}