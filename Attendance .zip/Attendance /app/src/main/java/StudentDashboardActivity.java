package com.collegeattendance;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class StudentDashboardActivity extends AppCompatActivity {

    Button joinLectureBtn, showQrBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);

        joinLectureBtn = findViewById(R.id.joinLectureBtn);
        showQrBtn = findViewById(R.id.showQrBtn);

        // TODO: connect to OTP + QR system
    }
}